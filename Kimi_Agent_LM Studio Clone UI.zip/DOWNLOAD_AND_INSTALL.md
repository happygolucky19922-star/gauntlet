# 🎮 LM Studio Clone: OpenClaw Edition
## Download & Installation Guide

---

## 🌐 Live Web App (Try Instantly!)

**https://zxqddorfr7rpi.ok.kimi.link**

No download required! Works in Chrome, Edge, Safari, and Firefox.

---

## 📱 QR Code - Scan to Install

![QR Code](qr-code.png)

Scan this code with your phone camera to open the app instantly!

---

## 💻 Desktop Download

### 📦 Download Package (180 KB)

Choose your preferred format:

| Format | Size | Download |
|--------|------|----------|
| **ZIP** | 180 KB | [lm-studio-clone-desktop.zip](lm-studio-clone-desktop.zip) |
| **TAR.GZ** | 179 KB | [lm-studio-clone-desktop.tar.gz](lm-studio-clone-desktop.tar.gz) |

---

## 🚀 Installation Instructions

### Windows

1. **Download** `lm-studio-clone-desktop.zip`
2. **Extract** the ZIP file to your Desktop or any folder
3. **Double-click** `launch-windows.bat`
4. The app opens in Chrome/Edge as a standalone window!

**Alternative:** Open `index.html` directly in Chrome or Edge

---

### macOS

1. **Download** `lm-studio-clone-desktop.zip`
2. **Extract** the ZIP file
3. **Right-click** `launch-mac.command` → "Open"
4. Click "Open" in the security dialog
5. The app opens in Safari/Chrome!

**Alternative:** Open `index.html` directly in Safari or Chrome

---

### Linux

1. **Download** `lm-studio-clone-desktop.tar.gz`
2. **Extract** the archive:
   ```bash
   tar -xzf lm-studio-clone-desktop.tar.gz
   ```
3. **Run** the launcher:
   ```bash
   cd lm-studio-clone-desktop
   ./launch-linux.sh
   ```

**Alternative:** Run `python3 -m http.server 8080` and open `http://localhost:8080`

---

## 📲 Install to Home Screen (PWA)

### On Mobile (iOS/Android):

1. Open **https://zxqddorfr7rpi.ok.kimi.link** in Chrome or Safari
2. Tap the **"Install"** button at the top
3. Follow the prompts
4. App icon appears on your home screen!

### On Desktop (Chrome/Edge):

1. Open the web app
2. Click **"Install App"** button in the header
3. The app installs as a standalone desktop app!

---

## 🎮 What's Inside

```
lm-studio-clone-desktop/
├── 📄 index.html              # Main app
├── 📂 assets/                 # JS & CSS bundles
│   ├── index-*.js
│   └── index-*.css
├── 📂 icons/                  # All icon sizes
│   ├── icon-32x32.png
│   ├── icon-192x192.png
│   └── ... (9 sizes total)
├── 📄 manifest.json           # PWA manifest
├── 📄 sw.js                   # Service worker
├── 📄 qr-code.png             # QR code image
├── 📄 README.txt              # Full documentation
├── 🖥️ launch-windows.bat      # Windows launcher
├── 🍎 launch-mac.command      # Mac launcher
└── 🐧 launch-linux.sh         # Linux launcher
```

---

## ✨ Features Included

### 🎯 OpenClaw Gamification
- **XP System** - Earn XP from tests and achievements
- **Level Up** - Progress from Level 1 to infinity
- **Streak Counter** - Build consecutive test streaks
- **Rarity System** - Common, Rare, Epic, Legendary models
- **Power Ratings** - Each model has a power score

### 🤖 Model Management
- 8 pre-configured models (Llama 3, Phi-3, Mistral, etc.)
- One-click downloads from HuggingFace/GitHub
- Download progress tracking
- Easy model switching

### 💬 Chat Interface
- **File Upload** - Images, videos, documents, code
- **Connectors** - GitHub, Web Search, PostgreSQL, Cloud
- **AI Agents** - Code Assistant, Researcher, Creative, Data Analyst
- **Media Gallery** - Browse and attach images/videos

### 🧪 Test Arena
- 22 tests across 8 categories
- Difficulty levels: Easy, Medium, Hard, Expert
- XP rewards for each test
- Speed run challenges

### 🏆 Achievements (8 Total)
| Achievement | Rarity | XP |
|-------------|--------|-----|
| First Blood | Bronze | 10 |
| Model Collector | Silver | 25 |
| Chat Master | Gold | 50 |
| Code Warrior | Gold | 75 |
| Legendary Tester | Platinum | 150 |
| Connector | Silver | 30 |
| Agent Handler | Gold | 40 |
| Speed Runner | Bronze | 20 |

---

## 🛠️ System Requirements

| Requirement | Minimum |
|-------------|---------|
| **OS** | Windows 10, macOS 10.14, Ubuntu 18.04 |
| **Browser** | Chrome 90+, Edge 90+, Safari 14+, Firefox 88+ |
| **RAM** | 4 GB |
| **Storage** | 10 MB (app only) |
| **Internet** | Required for model downloads |

---

## 🎮 How to Play

1. **Launch the App**
   - Double-click the launcher for your OS
   - Or open `index.html` in a browser

2. **Select a Model**
   - Go to the "Models" tab
   - Choose a downloaded model (or download one)
   - Legendary models have the highest power!

3. **Start Chatting**
   - Click "New Chat"
   - Type messages or upload files
   - Use connectors and agents for extra power

4. **Enter the Test Arena**
   - Click "Test Arena" button
   - Select tests to run
   - Earn XP and level up!

5. **Unlock Achievements**
   - Check the "Achievements" tab
   - Complete challenges
   - Collect all 8 achievements!

---

## 🔧 Troubleshooting

### App won't open?
→ Use Chrome or Edge for best experience

### Install button not showing?
→ Use Chrome/Edge on desktop
→ Use Safari on iOS

### Offline mode not working?
→ Load the app once while online
→ Service worker will cache for offline use

### Models won't download?
→ Check internet connection
→ Models are simulated (real LLM integration needed)

---

## 📜 License

MIT License - Free to use, modify, and distribute!

---

## 🙏 Credits

- Inspired by **LM Studio** and **OpenClaw**
- Built with **React**, **Tailwind CSS**, and **love** ❤️

---

**Enjoy your gamified LLM testing experience!** 🎮⚔️🏆
