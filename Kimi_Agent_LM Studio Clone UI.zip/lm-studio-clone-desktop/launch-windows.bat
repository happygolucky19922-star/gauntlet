@echo off
chcp 65001 >nul
title LM Studio Clone: OpenClaw Edition
cls

echo.
echo ╔══════════════════════════════════════════════════════════════════╗
echo ║                                                                  ║
echo ║   LM Studio Clone: OpenClaw Edition - Desktop Launcher          ║
echo ║                                                                  ║
echo ╚══════════════════════════════════════════════════════════════════╝
echo.
echo Starting LM Studio Clone...
echo.
echo This will open the app in your default browser.
echo For best experience, use Chrome or Edge.
echo.
echo Press any key to continue...
pause >nul

:: Try to open with Chrome first
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="%~dp0index.html" --window-size=1400,900
    goto :done
)

if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --app="%~dp0index.html" --window-size=1400,900
    goto :done
)

:: Try Edge
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="%~dp0index.html" --window-size=1400,900
    goto :done
)

:: Fallback to default browser
start "" "%~dp0index.html"

:done
echo.
echo LM Studio Clone is launching!
echo.
echo If it doesn't open automatically, please open index.html manually.
echo.
timeout /t 3 >nul
