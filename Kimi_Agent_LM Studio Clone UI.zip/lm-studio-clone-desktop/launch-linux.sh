#!/bin/bash

clear

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║                                                                  ║"
echo "║   LM Studio Clone: OpenClaw Edition - Desktop Launcher          ║"
echo "║                                                                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "Starting LM Studio Clone..."
echo ""
echo "This will open the app in your default browser."
echo "For best experience, use Chrome or Firefox."
echo ""

# Get the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Try different browsers
if command -v google-chrome &> /dev/null; then
    google-chrome --app="file://$DIR/index.html" --window-size=1400,900 &
elif command -v chromium &> /dev/null; then
    chromium --app="file://$DIR/index.html" --window-size=1400,900 &
elif command -v firefox &> /dev/null; then
    firefox "file://$DIR/index.html" &
elif command -v xdg-open &> /dev/null; then
    xdg-open "file://$DIR/index.html" &
else
    echo "Could not detect browser. Please open index.html manually."
    exit 1
fi

echo ""
echo "LM Studio Clone is launching!"
echo ""
echo "If it doesn't open automatically, please open index.html manually."
echo ""

sleep 2
