#!/bin/bash

clear

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║                                                                  ║"
echo "║   LM Studio Clone: OpenClaw Edition - Desktop Launcher          ║"
echo "║                                                                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "Starting LM Studio Clone..."
echo ""
echo "This will open the app in your default browser."
echo "For best experience, use Chrome or Safari."
echo ""

# Get the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Open in Chrome if available, otherwise default browser
if command -v /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome &> /dev/null; then
    open -a "Google Chrome" --args --app="file://$DIR/index.html" --window-size=1400,900
elif command -v /Applications/Safari.app/Contents/MacOS/Safari &> /dev/null; then
    open -a Safari "file://$DIR/index.html"
else
    open "file://$DIR/index.html"
fi

echo ""
echo "LM Studio Clone is launching!"
echo ""
echo "If it doesn't open automatically, please open index.html manually."
echo ""

sleep 2
