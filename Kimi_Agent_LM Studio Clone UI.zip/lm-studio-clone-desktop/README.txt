╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   ██╗     ███╗   ███╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗      ║
║   ██║     ████╗ ████║    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗     ║
║   ██║     ██╔████╔██║    ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║     ║
║   ██║     ██║╚██╔╝██║    ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║     ║
║   ███████╗██║ ╚═╝ ██║    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝     ║
║   ╚══════╝╚═╝     ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝      ║
║                                                                              ║
║                    OPENCLAW EDITION v1.0 - DESKTOP BUILD                     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

🎮 WELCOME TO LM STUDIO CLONE: OPENCLAW EDITION!

This is a gamified LLM testing platform inspired by OpenClaw. Test AI models,
earn XP, unlock achievements, and level up!

═══════════════════════════════════════════════════════════════════════════════
📁 PACKAGE CONTENTS
═══════════════════════════════════════════════════════════════════════════════

📄 index.html          - Main application entry point
📂 assets/             - JavaScript and CSS bundles
📂 icons/              - Application icons (all sizes)
📄 manifest.json       - PWA manifest
📄 sw.js               - Service worker for offline support
📄 qr-code.png         - QR code for mobile install
📂 screenshots/        - App screenshots

═══════════════════════════════════════════════════════════════════════════════
🚀 QUICK START
═══════════════════════════════════════════════════════════════════════════════

WINDOWS:
────────
1. Double-click "launch-windows.bat"
2. Or open index.html in Chrome/Edge

MAC:
────
1. Double-click "launch-mac.command"
2. Or open index.html in Safari/Chrome

LINUX:
──────
1. Double-click "launch-linux.sh"
2. Or run: python3 -m http.server 8080

═══════════════════════════════════════════════════════════════════════════════
🎯 FEATURES
═══════════════════════════════════════════════════════════════════════════════

🤖 MODEL MANAGEMENT
   • Download models from HuggingFace & GitHub
   • One-click model switching
   • Rarity system (Common, Rare, Epic, Legendary)
   • Power ratings for each model

💬 CHAT INTERFACE
   • File upload (images, videos, documents)
   • Connectors (GitHub, Web Search, PostgreSQL, Cloud)
   • AI Agents (Code Assistant, Researcher, Creative, Data Analyst)
   • Media gallery for images/videos

🧪 TEST ARENA
   • 22 tests across 8 categories
   • Difficulty levels (Easy, Medium, Hard, Expert)
   • XP rewards for each test
   • Speed run challenges

🏆 ACHIEVEMENT SYSTEM
   • 8 achievements to unlock
   • Bronze, Silver, Gold, Platinum rarities
   • XP bonuses for completion

📊 PLAYER PROGRESSION
   • Level up system
   • XP bar
   • Streak counter
   • Achievement tracker

═══════════════════════════════════════════════════════════════════════════════
📱 INSTALL TO HOME SCREEN
═══════════════════════════════════════════════════════════════════════════════

1. Open the app in Chrome, Edge, or Safari
2. Click "Install" button in the header
3. Follow browser prompts
4. App icon appears on home screen!

OR scan the QR code (qr-code.png) with your phone!

═══════════════════════════════════════════════════════════════════════════════
🎮 HOW TO PLAY
═══════════════════════════════════════════════════════════════════════════════

1. SELECT A MODEL
   • Choose from downloaded models
   • Each has rarity and power rating
   • Legendary models are the strongest!

2. START A CHAT
   • Type messages or upload files
   • Use connectors for external data
   • Activate AI agents for specialized help

3. ENTER THE TEST ARENA
   • Click "Test Arena" or "Battle All"
   • Complete tests to earn XP
   • Faster completion = more bragging rights!

4. UNLOCK ACHIEVEMENTS
   • Check the Achievements tab
   • Complete challenges to earn rewards
   • Collect them all!

5. LEVEL UP
   • Earn XP from tests and achievements
   • Watch your level increase
   • Build your streak for bonus XP!

═══════════════════════════════════════════════════════════════════════════════
🛠️ TECHNICAL INFO
═══════════════════════════════════════════════════════════════════════════════

Stack: React + TypeScript + Tailwind CSS + Vite
PWA: Service worker enabled for offline use
Icons: All standard sizes included
Compatibility: Chrome, Edge, Safari, Firefox

═══════════════════════════════════════════════════════════════════════════════
🔧 TROUBLESHOOTING
═══════════════════════════════════════════════════════════════════════════════

App won't open?
→ Use a modern browser (Chrome/Edge recommended)

Install button not showing?
→ Use Chrome or Edge on desktop
→ Use Safari on iOS

Offline mode not working?
→ Load the app once while online
→ Service worker will cache assets

═══════════════════════════════════════════════════════════════════════════════
📜 LICENSE
═══════════════════════════════════════════════════════════════════════════════

MIT License - Free to use, modify, and distribute!

═══════════════════════════════════════════════════════════════════════════════
🙏 CREDITS
═══════════════════════════════════════════════════════════════════════════════

Inspired by LM Studio and OpenClaw
Built with React, Tailwind CSS, and love ❤️

═══════════════════════════════════════════════════════════════════════════════

                    Happy Testing! 🎮⚔️🏆

═══════════════════════════════════════════════════════════════════════════════
