# LM Studio Clone

A desktop application for managing and testing local Large Language Models (LLMs), inspired by LM Studio.

![LM Studio Clone](screenshot.png)

## Features

### 🤖 Model Management
- **Download Models**: Directly download models from HuggingFace and GitHub
- **Local Model Switching**: Easy one-click model switching
- **Model Zoo**: Pre-configured popular models (Llama 3, Phi-3, Mistral, Qwen2, Gemma, etc.)
- **Download Progress**: Real-time download progress tracking
- **Model Info**: Size, tags, and description for each model

### 💬 Chat Interface
- **Beautiful UI**: Dark theme with glassmorphism effects
- **Message History**: Persistent conversation history
- **Model Indicator**: See which model generated each response
- **Typing Indicator**: Real-time generation feedback
- **Quick Suggestions**: Start conversations with suggested prompts

### 🧪 Comprehensive Test Suite
Test your models across 8 categories:
- **Chat**: General conversation, context memory, multi-turn dialogue
- **Code**: Python functions, debugging, algorithm explanation, refactoring
- **Health**: Medical info, first aid, nutrition advice
- **Law**: Legal concepts, contract basics, copyright
- **Political**: Political systems, policy analysis, international relations
- **Video**: Video scripts, scene descriptions
- **Audio**: Podcast scripts, voice assistant design
- **Images**: Image prompts, visual descriptions

### 🧠 Memory & Testing
- **Conversation History**: Save and revisit past conversations
- **Test Results**: Track model performance across categories
- **Response Time**: Measure model inference speed
- **Batch Testing**: Run all tests in a category at once

## Installation

### Download Pre-built Binaries

Download the latest release for your platform:
- **Windows**: `LM-Studio-Clone_1.0.0_x64-setup.exe`
- **macOS**: `LM-Studio-Clone_1.0.0_x64.dmg`
- **Linux**: `lm-studio-clone_1.0.0_amd64.deb` or `LM-Studio-Clone-1.0.0.x86_64.rpm`

### Build from Source

#### Prerequisites
- [Node.js](https://nodejs.org/) (v18 or higher)
- [Rust](https://rustup.rs/) (for Tauri)
- [Git](https://git-scm.com/)

#### Steps

1. Clone the repository:
```bash
git clone https://github.com/yourusername/lm-studio-clone.git
cd lm-studio-clone
```

2. Install dependencies:
```bash
npm install
```

3. Run in development mode:
```bash
npm run tauri-dev
```

4. Build for production:
```bash
npm run tauri-build
```

The built application will be in `src-tauri/target/release/bundle/`.

## Usage

### Starting a Conversation
1. Select a downloaded model from the sidebar
2. Click "New Chat" or select an existing conversation
3. Type your message and press Enter

### Downloading Models
1. Switch to the "Models" tab in the sidebar
2. Browse available models or search
3. Click "Download" on the model you want
4. Wait for the download to complete

### Running Tests
1. Click the sparkle icon (✨) in the header or switch to the "Tests" tab
2. Select a test category or "All Tests"
3. Click "Run" on individual tests or "Run All Tests"
4. View results and response times

### Model Settings
1. Click the settings icon (⚙️) in the header
2. Adjust temperature, max tokens, and context length
3. Customize the system prompt

## Architecture

### Frontend
- **React 19**: UI framework
- **TypeScript**: Type safety
- **Tailwind CSS**: Styling
- **shadcn/ui**: UI components
- **Framer Motion**: Animations
- **Lucide React**: Icons

### Desktop Framework
- **Tauri**: Rust-based desktop framework
- **WebView2**: Windows rendering engine
- **WKWebView**: macOS rendering engine
- **WebKitGTK**: Linux rendering engine

### State Management
- React hooks for local state
- LocalStorage for persistence (conversations, settings)

## Roadmap

- [ ] Actual LLM integration (llama.cpp, ollama)
- [ ] GGUF model support
- [ ] GPU acceleration
- [ ] RAG (Retrieval-Augmented Generation)
- [ ] Document upload and chat
- [ ] Code syntax highlighting
- [ ] Markdown rendering
- [ ] Export conversations
- [ ] Custom model sources
- [ ] Plugin system

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Inspired by [LM Studio](https://lmstudio.ai/)
- Icons by [Lucide](https://lucide.dev/)
- UI components by [shadcn/ui](https://ui.shadcn.com/)

## Disclaimer

This is a clone/imitation of LM Studio for educational purposes. It is not affiliated with or endorsed by LM Studio. For the official application, please visit [lmstudio.ai](https://lmstudio.ai/).
