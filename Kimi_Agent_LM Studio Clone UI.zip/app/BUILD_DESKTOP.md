# Building LM Studio Clone Desktop App

This guide will help you build the desktop version of LM Studio Clone using Tauri.

## Quick Start

### Option 1: Use Pre-built Web Version
The web version is already deployed and ready to use:
**https://zxqddorfr7rpi.ok.kimi.link**

### Option 2: Build Desktop App

#### Prerequisites

1. **Node.js** (v18 or higher)
   - Download from: https://nodejs.org/
   - Verify: `node --version`

2. **Rust** (required for Tauri)
   - Install on Windows: Download from https://rustup.rs/
   - Install on macOS/Linux:
     ```bash
     curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
     ```
   - Verify: `rustc --version`

3. **Platform-specific dependencies**

   **Windows:**
   - Install Microsoft Visual Studio C++ Build Tools
   - Install WebView2 Runtime (usually pre-installed on Windows 10/11)

   **macOS:**
   - Install Xcode Command Line Tools:
     ```bash
     xcode-select --install
     ```

   **Linux:**
   - Install required packages:
     ```bash
     # Ubuntu/Debian
     sudo apt update
     sudo apt install libwebkit2gtk-4.0-dev build-essential curl wget file libssl-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev

     # Fedora
     sudo dnf install webkit2gtk3-devel openssl-devel curl wget file libappindicator-gtk3-devel librsvg2-devel

     # Arch
     sudo pacman -S webkit2gtk base-devel curl wget file openssl appindicator-gtk librsvg
     ```

#### Build Steps

1. **Navigate to the app directory:**
   ```bash
   cd /path/to/lm-studio-clone
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Build the desktop app:**
   ```bash
   npm run tauri-build
   ```

4. **Find your installer:**
   - **Windows**: `src-tauri/target/release/bundle/msi/*.msi` or `*.exe`
   - **macOS**: `src-tauri/target/release/bundle/dmg/*.dmg`
   - **Linux**: `src-tauri/target/release/bundle/deb/*.deb` or `*.AppImage`

#### Development Mode

To run in development mode with hot reload:
```bash
npm run tauri-dev
```

## Platform-Specific Build Instructions

### Windows

#### Build MSI Installer
```bash
npm run tauri-build -- --bundles msi
```

#### Build NSIS Installer (.exe)
```bash
npm run tauri-build -- --bundles nsis
```

### macOS

#### Build DMG
```bash
npm run tauri-build
```

#### Build for Apple Silicon (M1/M2)
```bash
rustup target add aarch64-apple-darwin
npm run tauri-build -- --target aarch64-apple-darwin
```

#### Build for Intel Macs
```bash
rustup target add x86_64-apple-darwin
npm run tauri-build -- --target x86_64-apple-darwin
```

#### Universal Binary (both architectures)
```bash
rustup target add aarch64-apple-darwin x86_64-apple-darwin
npm run tauri-build -- --target universal-apple-darwin
```

### Linux

#### Build DEB (Ubuntu/Debian)
```bash
npm run tauri-build -- --bundles deb
```

#### Build RPM (Fedora/RHEL)
```bash
npm run tauri-build -- --bundles rpm
```

#### Build AppImage
```bash
npm run tauri-build -- --bundles appimage
```

## Customization

### Change App Name
Edit `src-tauri/tauri.conf.json`:
```json
{
  "tauri": {
    "bundle": {
      "identifier": "com.yourcompany.yourapp"
    },
    "windows": [{
      "title": "Your App Name"
    }]
  }
}
```

### Change Icons
Replace files in `src-tauri/icons/`:
- `32x32.png` - Taskbar icon
- `128x128.png` - App icon
- `128x128@2x.png` - Retina display icon
- `icon.icns` - macOS icon
- `icon.ico` - Windows icon

### Change Window Size
Edit `src-tauri/tauri.conf.json`:
```json
{
  "tauri": {
    "windows": [{
      "width": 1400,
      "height": 900,
      "minWidth": 1000,
      "minHeight": 600
    }]
  }
}
```

## Troubleshooting

### "Rust is not installed"
Run the Rust installer and restart your terminal:
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env
```

### "WebView2 not found" (Windows)
Download and install WebView2 Runtime:
https://developer.microsoft.com/en-us/microsoft-edge/webview2/

### Build fails on Linux
Make sure all dependencies are installed:
```bash
sudo apt install libwebkit2gtk-4.0-dev build-essential
```

### "error: linker cc not found" (Linux)
Install build-essential:
```bash
sudo apt install build-essential
```

### App icon not showing
Make sure icon files are in `src-tauri/icons/` and properly formatted:
- PNG files should be exact sizes (32x32, 128x128, etc.)
- ICO file should contain multiple sizes
- ICNS file is for macOS only

## Distribution

After building, you can distribute:

1. **Windows**: `.msi` or `.exe` installer
2. **macOS**: `.dmg` disk image
3. **Linux**: `.deb`, `.rpm`, or `.AppImage`

### Code Signing (Recommended for distribution)

#### Windows
Use a code signing certificate from a trusted CA like DigiCert or Sectigo.

#### macOS
Sign with your Apple Developer ID:
```bash
codesign --force --sign "Developer ID Application: Your Name" path/to/app
```

#### Linux
AppImage and DEB packages don't require code signing, but you can sign DEB packages with GPG.

## Updates

To enable auto-updater:
1. Edit `src-tauri/tauri.conf.json`
2. Set `"updater": { "active": true }`
3. Configure update server endpoint

See Tauri documentation for more details: https://tauri.app/v1/guides/distribution/updater

## Need Help?

- Tauri Documentation: https://tauri.app/v1/guides/
- Tauri Discord: https://discord.gg/tauri
- GitHub Issues: https://github.com/tauri-apps/tauri/issues
