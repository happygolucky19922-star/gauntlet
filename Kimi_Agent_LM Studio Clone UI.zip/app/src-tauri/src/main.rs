// Prevents additional console window on Windows in release
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::{Manager, WindowEvent};

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            // Get the main window
            let main_window = app.get_window("main").unwrap();
            
            // Set up window event handlers
            main_window.on_window_event(|event| {
                match event {
                    WindowEvent::CloseRequested { api, .. } => {
                        // Handle close request
                        println!("Window close requested");
                    }
                    _ => {}
                }
            });
            
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            greet,
            get_app_version,
            open_external
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

// Example command
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}

// Get app version
#[tauri::command]
fn get_app_version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

// Open external URL
#[tauri::command]
fn open_external(url: &str) -> Result<(), String> {
    match open::that(url) {
        Ok(_) => Ok(()),
        Err(e) => Err(format!("Failed to open URL: {}", e))
    }
}
