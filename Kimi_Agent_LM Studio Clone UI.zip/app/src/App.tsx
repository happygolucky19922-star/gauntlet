import { useState, useEffect, useRef } from 'react'
import { 
  MessageSquare, Download, Cpu, Settings, 
  Search, Plus, Send, Menu, X, 
  Check, Trash2, 
  Play, Sparkles,
  Code, Stethoscope, Scale, Landmark, Video, Mic, Image,
  Database,
  // New icons for chat bar
  Paperclip, Plug, Bot, Film, Camera, 
  // Install/Download icons
  ArrowDownToLine, CheckCircle2,
  // File types
  FileText, FileCode, FileImage, FileVideo, FileAudio,
  // Connector icons
  Github, Globe, Database as DatabaseIcon, Cloud,
  // Agent icons
  Workflow, Target,
  // OpenClaw / Game icons
  Gamepad2, Trophy, Zap, Flame, Sword, Gem, Crown,
  ChevronRight
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { toast } from 'sonner'
import './App.css'

// Types
interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
  model?: string
  attachments?: Attachment[]
}

interface Attachment {
  id: string
  type: 'image' | 'video' | 'audio' | 'document' | 'code'
  name: string
  url: string
  size: string
}

interface Model {
  id: string
  name: string
  description: string
  size: string
  tags: string[]
  source: 'huggingface' | 'github' | 'local'
  downloaded: boolean
  progress?: number
  rarity?: 'common' | 'rare' | 'epic' | 'legendary'
  power?: number
}

interface Conversation {
  id: string
  title: string
  messages: Message[]
  modelId: string
  createdAt: Date
  updatedAt: Date
}

interface TestPrompt {
  id: string
  category: string
  name: string
  prompt: string
  description: string
  difficulty: 'easy' | 'medium' | 'hard' | 'expert'
  xp: number
}

interface Connector {
  id: string
  name: string
  description: string
  icon: any
  connected: boolean
  color: string
}

interface Agent {
  id: string
  name: string
  description: string
  icon: any
  active: boolean
  capabilities: string[]
  level: number
}

// OpenClaw-inspired Achievement System
interface Achievement {
  id: string
  name: string
  description: string
  icon: any
  unlocked: boolean
  xp: number
  rarity: 'bronze' | 'silver' | 'gold' | 'platinum'
}

// Test Prompts Data with OpenClaw difficulty
const testPrompts: TestPrompt[] = [
  // Chat - Easy
  { id: '1', category: 'chat', name: 'General Conversation', prompt: 'Hello! How are you today? Tell me a bit about yourself and what you can help me with.', description: 'Basic greeting and introduction test', difficulty: 'easy', xp: 10 },
  { id: '2', category: 'chat', name: 'Context Memory', prompt: 'My name is Alex. Remember this. (Wait for response) Now, what is my name?', description: 'Tests short-term memory retention', difficulty: 'easy', xp: 15 },
  { id: '3', category: 'chat', name: 'Multi-turn Dialogue', prompt: 'Let\'s have a conversation about climate change. What are your thoughts?', description: 'Tests conversation flow', difficulty: 'medium', xp: 25 },
  
  // Code - Medium to Hard
  { id: '4', category: 'code', name: 'Python Function', prompt: 'Write a Python function to calculate the Fibonacci sequence up to n numbers, with proper error handling and documentation.', description: 'Tests code generation', difficulty: 'medium', xp: 30 },
  { id: '5', category: 'code', name: 'Debug Code', prompt: 'Debug this code:\ndef divide(a, b):\n    return a/b\nprint(divide(5, 0))', description: 'Tests debugging capabilities', difficulty: 'easy', xp: 20 },
  { id: '6', category: 'code', name: 'Explain Algorithm', prompt: 'Explain how Dijkstra\'s algorithm works and provide a clean implementation in JavaScript.', description: 'Tests algorithm explanation', difficulty: 'hard', xp: 50 },
  { id: '7', category: 'code', name: 'Refactor Code', prompt: 'Refactor this code to be more efficient:\nfor i in range(len(list)):\n    print(list[i])', description: 'Tests code optimization', difficulty: 'medium', xp: 25 },
  
  // Health - Medium
  { id: '8', category: 'health', name: 'Medical Info', prompt: 'What are the common symptoms of diabetes? When should someone see a doctor?', description: 'Tests medical knowledge', difficulty: 'medium', xp: 30 },
  { id: '9', category: 'health', name: 'First Aid', prompt: 'What should I do if someone is having a severe allergic reaction?', description: 'Tests emergency response', difficulty: 'hard', xp: 45 },
  { id: '10', category: 'health', name: 'Nutrition Advice', prompt: 'What are some heart-healthy foods and why are they beneficial?', description: 'Tests nutrition knowledge', difficulty: 'easy', xp: 15 },
  
  // Law - Hard
  { id: '11', category: 'law', name: 'Legal Concept', prompt: 'Explain the concept of "reasonable doubt" in criminal law.', description: 'Tests legal knowledge', difficulty: 'medium', xp: 35 },
  { id: '12', category: 'law', name: 'Contract Basics', prompt: 'What are the essential elements of a valid contract?', description: 'Tests contract law', difficulty: 'medium', xp: 30 },
  { id: '13', category: 'law', name: 'Copyright', prompt: 'What is fair use in copyright law? Provide examples.', description: 'Tests IP knowledge', difficulty: 'hard', xp: 50 },
  
  // Political - Expert
  { id: '14', category: 'political', name: 'Political Systems', prompt: 'Compare and contrast parliamentary and presidential systems of government.', description: 'Tests political science', difficulty: 'medium', xp: 35 },
  { id: '15', category: 'political', name: 'Policy Analysis', prompt: 'What are the main arguments for and against universal basic income?', description: 'Tests policy analysis', difficulty: 'hard', xp: 55 },
  { id: '16', category: 'political', name: 'International Relations', prompt: 'Explain the concept of soft power in international relations.', description: 'Tests IR knowledge', difficulty: 'expert', xp: 75 },
  
  // Video - Medium
  { id: '17', category: 'video', name: 'Video Script', prompt: 'Write a 60-second video script explaining blockchain technology to beginners.', description: 'Tests script writing', difficulty: 'medium', xp: 30 },
  { id: '18', category: 'video', name: 'Scene Description', prompt: 'Describe a cinematic opening scene for a sci-fi movie about AI consciousness.', description: 'Tests visual storytelling', difficulty: 'hard', xp: 50 },
  
  // Audio - Medium
  { id: '19', category: 'audio', name: 'Podcast Script', prompt: 'Write an engaging introduction for a podcast episode about the future of AI.', description: 'Tests audio content', difficulty: 'medium', xp: 25 },
  { id: '20', category: 'audio', name: 'Voice Assistant', prompt: 'How would you design a voice assistant response for setting a timer?', description: 'Tests voice UI design', difficulty: 'easy', xp: 20 },
  
  // Pics - Easy to Medium
  { id: '21', category: 'pics', name: 'Image Prompt', prompt: 'Write a detailed prompt for generating an image of a futuristic city at sunset.', description: 'Tests image prompting', difficulty: 'easy', xp: 15 },
  { id: '22', category: 'pics', name: 'Visual Description', prompt: 'Describe the Mona Lisa painting in vivid detail.', description: 'Tests visual description', difficulty: 'medium', xp: 25 },
]

// Sample Models with OpenClaw rarity system
const sampleModels: Model[] = [
  { id: 'llama-3-8b', name: 'Llama 3 8B', description: 'Meta\'s efficient open source LLM', size: '4.7 GB', tags: ['General', 'Chat'], source: 'huggingface', downloaded: true, rarity: 'rare', power: 75 },
  { id: 'llama-3-70b', name: 'Llama 3 70B', description: 'Meta\'s most capable open source LLM', size: '40 GB', tags: ['General', 'Advanced'], source: 'huggingface', downloaded: false, rarity: 'legendary', power: 98 },
  { id: 'phi-3-mini', name: 'Phi-3 Mini', description: 'Microsoft\'s compact powerful model', size: '2.3 GB', tags: ['General', 'Efficient'], source: 'huggingface', downloaded: true, rarity: 'common', power: 65 },
  { id: 'mistral-7b', name: 'Mistral 7B', description: 'High performance 7B parameter model', size: '4.1 GB', tags: ['General', 'Chat'], source: 'huggingface', downloaded: false, rarity: 'rare', power: 80 },
  { id: 'qwen2-7b', name: 'Qwen2 7B', description: 'Alibaba\'s bilingual model', size: '4.4 GB', tags: ['Multilingual', 'Code'], source: 'huggingface', downloaded: false, rarity: 'epic', power: 85 },
  { id: 'gemma-2b', name: 'Gemma 2B', description: 'Google\'s lightweight open model', size: '1.6 GB', tags: ['General', 'Efficient'], source: 'huggingface', downloaded: true, rarity: 'common', power: 60 },
  { id: 'codellama-7b', name: 'CodeLlama 7B', description: 'Meta\'s code-specialized model', size: '3.8 GB', tags: ['Code', 'Programming'], source: 'github', downloaded: false, rarity: 'epic', power: 88 },
  { id: 'neural-chat', name: 'Neural Chat 7B', description: 'Intel\'s chat-optimized model', size: '4.2 GB', tags: ['Chat', 'Assistant'], source: 'huggingface', downloaded: false, rarity: 'rare', power: 78 },
]

// Connectors Data
const sampleConnectors: Connector[] = [
  { id: 'github', name: 'GitHub', description: 'Access repositories and code', icon: Github, connected: false, color: '#333' },
  { id: 'web', name: 'Web Search', description: 'Search the internet', icon: Globe, connected: true, color: '#4285f4' },
  { id: 'postgres', name: 'PostgreSQL', description: 'Query databases', icon: DatabaseIcon, connected: false, color: '#336791' },
  { id: 'cloud', name: 'Cloud Storage', description: 'Access cloud files', icon: Cloud, connected: false, color: '#00a4ef' },
]

// Agents with levels
const sampleAgents: Agent[] = [
  { id: 'coder', name: 'Code Assistant', description: 'Write and debug code', icon: Code, active: false, capabilities: ['Write code', 'Debug', 'Explain', 'Refactor'], level: 5 },
  { id: 'researcher', name: 'Research Agent', description: 'Find and summarize information', icon: Target, active: false, capabilities: ['Search', 'Summarize', 'Cite sources'], level: 3 },
  { id: 'creative', name: 'Creative Writer', description: 'Generate creative content', icon: Sparkles, active: false, capabilities: ['Write stories', 'Poetry', 'Scripts'], level: 4 },
  { id: 'data', name: 'Data Analyst', description: 'Analyze and visualize data', icon: Workflow, active: false, capabilities: ['Analyze', 'Chart', 'Report'], level: 6 },
]

// OpenClaw Achievements
const sampleAchievements: Achievement[] = [
  { id: '1', name: 'First Blood', description: 'Run your first test', icon: Sword, unlocked: false, xp: 10, rarity: 'bronze' },
  { id: '2', name: 'Model Collector', description: 'Download 3 models', icon: Gem, unlocked: false, xp: 25, rarity: 'silver' },
  { id: '3', name: 'Chat Master', description: 'Send 50 messages', icon: MessageSquare, unlocked: false, xp: 50, rarity: 'gold' },
  { id: '4', name: 'Code Warrior', description: 'Complete all code tests', icon: Code, unlocked: false, xp: 75, rarity: 'gold' },
  { id: '5', name: 'Legendary Tester', description: 'Complete all tests with perfect score', icon: Crown, unlocked: false, xp: 150, rarity: 'platinum' },
  { id: '6', name: 'Connector', description: 'Connect all integrations', icon: Plug, unlocked: false, xp: 30, rarity: 'silver' },
  { id: '7', name: 'Agent Handler', description: 'Use all AI agents', icon: Bot, unlocked: false, xp: 40, rarity: 'gold' },
  { id: '8', name: 'Speed Runner', description: 'Complete a test in under 1 second', icon: Zap, unlocked: false, xp: 20, rarity: 'bronze' },
]

// Sample Conversations
const sampleConversations: Conversation[] = [
  {
    id: '1',
    title: 'Python Help',
    messages: [
      { id: '1', role: 'user', content: 'How do I write a Python function to read a file?', timestamp: new Date(Date.now() - 86400000) },
      { id: '2', role: 'assistant', content: 'Here\'s how you can read a file in Python:\n\n```python\ndef read_file(filename):\n    try:\n        with open(filename, \'r\') as file:\n            return file.read()\n    except FileNotFoundError:\n        return "File not found"\n```', timestamp: new Date(Date.now() - 86400000) }
    ],
    modelId: 'llama-3-8b',
    createdAt: new Date(Date.now() - 86400000),
    updatedAt: new Date(Date.now() - 86400000)
  },
]

function App() {
  // State
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState('chat')
  const [conversations, setConversations] = useState<Conversation[]>(sampleConversations)
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputMessage, setInputMessage] = useState('')
  const [selectedModel, setSelectedModel] = useState<Model>(sampleModels[0])
  const [models, setModels] = useState<Model[]>(sampleModels)
  const [searchQuery, setSearchQuery] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [testResults, setTestResults] = useState<Record<string, { passed: boolean; response: string; time: number }>>({})
  const [runningTests, setRunningTests] = useState<Set<string>>(new Set())
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({})
  const [showTestPanel, setShowTestPanel] = useState(false)
  const [selectedTestCategory, setSelectedTestCategory] = useState<string>('all')
  
  // New state for chat bar features
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [showConnectors, setShowConnectors] = useState(false)
  const [showAgents, setShowAgents] = useState(false)
  const [connectors, setConnectors] = useState<Connector[]>(sampleConnectors)
  const [agents] = useState<Agent[]>(sampleAgents)
  const [activeAgent, setActiveAgent] = useState<Agent | null>(null)
  const [showMediaGallery, setShowMediaGallery] = useState(false)
  const [mediaType, setMediaType] = useState<'video' | 'image' | null>(null)
  
  // OpenClaw Game State
  const [achievements, setAchievements] = useState<Achievement[]>(sampleAchievements)
  const [playerXP, setPlayerXP] = useState(0)
  const [playerLevel, setPlayerLevel] = useState(1)
  const [showAchievements, setShowAchievements] = useState(false)
  const [completedTests, setCompletedTests] = useState(0)
  const [showGameMode, setShowGameMode] = useState(false)
  const [streak, setStreak] = useState(0)
  
  // PWA Install State
  const [installPrompt, setInstallPrompt] = useState<any>(null)
  const [isInstalled, setIsInstalled] = useState(false)
  const [showInstallBanner, setShowInstallBanner] = useState(true)
  
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Calculate player level from XP
  useEffect(() => {
    const newLevel = Math.floor(playerXP / 100) + 1
    if (newLevel > playerLevel) {
      setPlayerLevel(newLevel)
      toast.success(`Level Up! You are now level ${newLevel}!`)
    }
  }, [playerXP, playerLevel])

  // Unlock achievement helper
  const unlockAchievement = (id: string) => {
    setAchievements(prev => prev.map(a => {
      if (a.id === id && !a.unlocked) {
        toast.success(`Achievement Unlocked: ${a.name}! +${a.xp} XP`, { duration: 4000 })
        setPlayerXP(xp => xp + a.xp)
        return { ...a, unlocked: true }
      }
      return a
    }))
  }

  // PWA Install Handler
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setInstallPrompt(e)
    }

    const handleAppInstalled = () => {
      setIsInstalled(true)
      setInstallPrompt(null)
      toast.success('App installed successfully!')
      unlockAchievement('1') // First Blood equivalent
    }

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    window.addEventListener('appinstalled', handleAppInstalled)

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
      window.removeEventListener('appinstalled', handleAppInstalled)
    }
  }, [])

  // Install App
  const installApp = async () => {
    if (!installPrompt) {
      toast.info('Installation not available. Try using Chrome or Edge browser.')
      return
    }
    
    installPrompt.prompt()
    const { outcome } = await installPrompt.userChoice
    
    if (outcome === 'accepted') {
      setIsInstalled(true)
      setInstallPrompt(null)
      toast.success('Installation started!')
    } else {
      toast.info('Installation cancelled')
    }
  }

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Start new conversation
  const startNewConversation = () => {
    const newConv: Conversation = {
      id: Date.now().toString(),
      title: 'New Conversation',
      messages: [],
      modelId: selectedModel.id,
      createdAt: new Date(),
      updatedAt: new Date()
    }
    setConversations([newConv, ...conversations])
    setCurrentConversation(newConv)
    setMessages([])
    setAttachments([])
    setActiveTab('chat')
  }

  // File Upload Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    Array.from(files).forEach(file => {
      const reader = new FileReader()
      reader.onload = (event) => {
        const newAttachment: Attachment = {
          id: Date.now().toString() + Math.random(),
          type: getFileType(file.type),
          name: file.name,
          url: event.target?.result as string,
          size: formatFileSize(file.size)
        }
        setAttachments(prev => [...prev, newAttachment])
        toast.success(`File "${file.name}" attached`)
      }
      reader.readAsDataURL(file)
    })
  }

  const getFileType = (mimeType: string): Attachment['type'] => {
    if (mimeType.startsWith('image/')) return 'image'
    if (mimeType.startsWith('video/')) return 'video'
    if (mimeType.startsWith('audio/')) return 'audio'
    if (mimeType.includes('code') || mimeType.includes('javascript') || mimeType.includes('python')) return 'code'
    return 'document'
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  }

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id))
  }

  // Send message
  const sendMessage = async () => {
    if (!inputMessage.trim() && attachments.length === 0) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date(),
      attachments: attachments.length > 0 ? attachments : undefined
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setAttachments([])
    setIsGenerating(true)

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateSimulatedResponse(inputMessage, attachments),
        timestamp: new Date(),
        model: selectedModel.name
      }
      setMessages(prev => [...prev, assistantMessage])
      setIsGenerating(false)
      
      // Check for Chat Master achievement
      if (messages.length >= 49) {
        unlockAchievement('3')
      }
      
      // Update conversation title if it's the first message
      if (messages.length === 0 && currentConversation) {
        const updatedConv = { ...currentConversation, title: inputMessage.slice(0, 30) + '...' || 'Image/File Upload' }
        setCurrentConversation(updatedConv)
        setConversations(prev => prev.map(c => c.id === updatedConv.id ? updatedConv : c))
      }
    }, 1500)
  }

  // Simulate AI response
  const generateSimulatedResponse = (input: string, attachments: Attachment[]): string => {
    if (attachments.length > 0) {
      const attachmentNames = attachments.map(a => a.name).join(', ')
      return `I've received your file(s): ${attachmentNames}\n\nI can see you've uploaded ${attachments.length} file(s). In a real implementation with vision capabilities, I would analyze the content of these files and provide relevant insights.\n\nFor now, this is a simulated response showing that the file upload feature is working correctly!`
    }
    
    const responses = [
      `I understand you're asking about "${input.slice(0, 50)}..." Let me provide a comprehensive response:\n\nThis is a simulated response from ${selectedModel.name}. In a real implementation, this would connect to the actual local LLM through an API endpoint.\n\nKey points to consider:\n1. The model is running locally on your machine\n2. Your data never leaves your device\n3. You have complete privacy and control`,
      `Great question! Here's what I know about that:\n\n${input.slice(0, 30)}... is an interesting topic. [This is a placeholder response - in production, this would be generated by the actual LLM]\n\nLet me know if you'd like me to elaborate on any specific aspect!`,
      `I'd be happy to help with that. Based on my training data, I can tell you that:\n\n- Point 1: Important information here\n- Point 2: Additional context\n- Point 3: Further details\n\nThis response is simulated for demonstration purposes.`
    ]
    return responses[Math.floor(Math.random() * responses.length)]
  }

  // Toggle Connector
  const toggleConnector = (id: string) => {
    setConnectors(prev => {
      const updated = prev.map(c => {
        if (c.id === id) {
          const newState = !c.connected
          toast.success(`${c.name} ${newState ? 'connected' : 'disconnected'}`)
          return { ...c, connected: newState }
        }
        return c
      })
      
      // Check for Connector achievement
      if (updated.every(c => c.connected)) {
        unlockAchievement('6')
      }
      
      return updated
    })
  }

  // Toggle Agent
  const toggleAgent = (agent: Agent) => {
    if (activeAgent?.id === agent.id) {
      setActiveAgent(null)
      toast.info(`${agent.name} deactivated`)
    } else {
      setActiveAgent(agent)
      toast.success(`${agent.name} activated`)
    }
    setShowAgents(false)
  }

  // Media Gallery
  const openMediaGallery = (type: 'video' | 'image') => {
    setMediaType(type)
    setShowMediaGallery(true)
  }

  // Sample media items
  const sampleMedia = [
    { id: '1', name: 'Sample 1', type: 'image', url: 'https://picsum.photos/400/300?random=1' },
    { id: '2', name: 'Sample 2', type: 'image', url: 'https://picsum.photos/400/300?random=2' },
    { id: '3', name: 'Sample 3', type: 'image', url: 'https://picsum.photos/400/300?random=3' },
    { id: '4', name: 'Sample 4', type: 'image', url: 'https://picsum.photos/400/300?random=4' },
  ]

  const selectMedia = (media: any) => {
    const newAttachment: Attachment = {
      id: Date.now().toString(),
      type: mediaType as 'image' | 'video',
      name: media.name,
      url: media.url,
      size: '2.4 MB'
    }
    setAttachments(prev => [...prev, newAttachment])
    setShowMediaGallery(false)
    toast.success(`${mediaType === 'image' ? 'Image' : 'Video'} added to message`)
  }

  // Download model
  const downloadModel = (modelId: string) => {
    setDownloadProgress(prev => ({ ...prev, [modelId]: 0 }))
    
    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        const current = prev[modelId] || 0
        if (current >= 100) {
          clearInterval(interval)
          setModels(prevModels => {
            const updated = prevModels.map(m => 
              m.id === modelId ? { ...m, downloaded: true } : m
            )
            
            // Check for Model Collector achievement
            const downloadedCount = updated.filter(m => m.downloaded).length
            if (downloadedCount >= 3) {
              unlockAchievement('2')
            }
            
            return updated
          })
          toast.success('Model downloaded successfully!')
          return { ...prev, [modelId]: 100 }
        }
        return { ...prev, [modelId]: current + Math.random() * 15 }
      })
    }, 500)
  }

  // Run test prompt
  const runTest = async (test: TestPrompt) => {
    setRunningTests(prev => new Set(prev).add(test.id))
    const startTime = Date.now()
    
    setTimeout(() => {
      const time = Date.now() - startTime
      setTestResults(prev => ({
        ...prev,
        [test.id]: {
          passed: true,
          response: `Test completed successfully. The model responded appropriately to the ${test.category} test prompt.\n\n[This is a simulated response for demonstration]`,
          time
        }
      }))
      setRunningTests(prev => {
        const newSet = new Set(prev)
        newSet.delete(test.id)
        return newSet
      })
      
      // Award XP
      setPlayerXP(xp => xp + test.xp)
      setCompletedTests(c => c + 1)
      setStreak(s => s + 1)
      
      // Check for First Blood
      if (completedTests === 0) {
        unlockAchievement('1')
      }
      
      // Check for Speed Runner
      if (time < 1000) {
        unlockAchievement('8')
      }
      
      toast.success(`Test "${test.name}" completed! +${test.xp} XP`)
    }, 2000 + Math.random() * 2000)
  }

  // Run all tests in category
  const runAllTests = (category: string) => {
    const tests = category === 'all' 
      ? testPrompts 
      : testPrompts.filter(t => t.category === category)
    
    tests.forEach((test, index) => {
      setTimeout(() => runTest(test), index * 500)
    })
  }

  // Load conversation
  const loadConversation = (conv: Conversation) => {
    setCurrentConversation(conv)
    setMessages(conv.messages)
    setActiveTab('chat')
  }

  // Delete conversation
  const deleteConversation = (id: string) => {
    setConversations(prev => prev.filter(c => c.id !== id))
    if (currentConversation?.id === id) {
      setCurrentConversation(null)
      setMessages([])
    }
  }

  // Filter models
  const filteredModels = models.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  // Filter test prompts
  const filteredTests = selectedTestCategory === 'all' 
    ? testPrompts 
    : testPrompts.filter(t => t.category === selectedTestCategory)

  // Categories
  const categories = [
    { id: 'all', name: 'All Tests', icon: Sparkles },
    { id: 'chat', name: 'Chat', icon: MessageSquare },
    { id: 'code', name: 'Code', icon: Code },
    { id: 'health', name: 'Health', icon: Stethoscope },
    { id: 'law', name: 'Law', icon: Scale },
    { id: 'political', name: 'Political', icon: Landmark },
    { id: 'video', name: 'Video', icon: Video },
    { id: 'audio', name: 'Audio', icon: Mic },
    { id: 'pics', name: 'Images', icon: Image },
  ]

  // Get file icon
  const getFileIcon = (type: Attachment['type']) => {
    switch (type) {
      case 'image': return FileImage
      case 'video': return FileVideo
      case 'audio': return FileAudio
      case 'code': return FileCode
      default: return FileText
    }
  }

  // Get rarity color
  const getRarityColor = (rarity?: string) => {
    switch (rarity) {
      case 'legendary': return 'from-yellow-400 via-orange-500 to-red-500'
      case 'epic': return 'from-purple-400 via-pink-500 to-rose-500'
      case 'rare': return 'from-blue-400 via-indigo-500 to-purple-500'
      default: return 'from-gray-400 via-gray-500 to-gray-600'
    }
  }

  // Get rarity glow
  const getRarityGlow = (rarity?: string) => {
    switch (rarity) {
      case 'legendary': return 'shadow-yellow-500/50'
      case 'epic': return 'shadow-purple-500/50'
      case 'rare': return 'shadow-blue-500/50'
      default: return 'shadow-gray-500/30'
    }
  }

  // Get difficulty color
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'expert': return 'text-red-400 bg-red-500/20'
      case 'hard': return 'text-orange-400 bg-orange-500/20'
      case 'medium': return 'text-yellow-400 bg-yellow-500/20'
      default: return 'text-green-400 bg-green-500/20'
    }
  }

  return (
    <TooltipProvider>
      <div className="h-screen w-screen bg-[#0d0d0d] text-white overflow-hidden flex neural-bg">
        {/* Install Banner */}
        {showInstallBanner && !isInstalled && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[100] bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-xl p-4 flex items-center gap-4 shadow-2xl animate-in slide-in-from-top">
            <Gamepad2 className="w-8 h-8" />
            <div>
              <p className="font-semibold">Install LM Studio Clone: OpenClaw Edition</p>
              <p className="text-sm text-white/80">Add to home screen for the full experience!</p>
            </div>
            <Button 
              onClick={installApp}
              className="bg-white text-purple-600 hover:bg-white/90 font-semibold"
            >
              <ArrowDownToLine className="w-4 h-4 mr-2" />
              Install
            </Button>
            <button 
              onClick={() => setShowInstallBanner(false)}
              className="p-1 hover:bg-white/20 rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Sidebar */}
        <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 bg-[#0a0a0a] border-r border-white/10 flex flex-col overflow-hidden`}>
          {/* Sidebar Header */}
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Gamepad2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg">LM Studio</h1>
                <p className="text-xs text-purple-400">OpenClaw Edition</p>
              </div>
            </div>
            
            {/* Player Stats Bar */}
            <div className="p-3 rounded-lg bg-gradient-to-r from-purple-900/50 to-indigo-900/50 border border-purple-500/30 mb-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-bold">Level {playerLevel}</span>
                </div>
                <span className="text-xs text-purple-300">{playerXP} XP</span>
              </div>
              <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 transition-all duration-500"
                  style={{ width: `${(playerXP % 100)}%` }}
                />
              </div>
              {streak > 0 && (
                <div className="flex items-center gap-1 mt-2 text-orange-400">
                  <Flame className="w-3 h-3" />
                  <span className="text-xs">{streak} streak!</span>
                </div>
              )}
            </div>
            
            <Button 
              onClick={startNewConversation}
              className="w-full btn-primary text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>

          {/* Sidebar Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid grid-cols-4 mx-4 mt-4 bg-white/5">
              <TabsTrigger value="chat" className="data-[state=active]:bg-indigo-500/20">
                <MessageSquare className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="models" className="data-[state=active]:bg-indigo-500/20">
                <Database className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="tests" className="data-[state=active]:bg-indigo-500/20">
                <Sparkles className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="achievements" className="data-[state=active]:bg-indigo-500/20">
                <Trophy className="w-4 h-4" />
              </TabsTrigger>
            </TabsList>

            {/* Chat Tab - Conversations */}
            <TabsContent value="chat" className="flex-1 flex flex-col m-0 mt-4">
              <ScrollArea className="flex-1 px-4">
                <div className="space-y-2">
                  {conversations.map(conv => (
                    <div
                      key={conv.id}
                      onClick={() => loadConversation(conv)}
                      className={`p-3 rounded-lg cursor-pointer group transition-all ${
                        currentConversation?.id === conv.id 
                          ? 'bg-indigo-500/20 border border-indigo-500/30' 
                          : 'hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{conv.title}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {conv.messages.length} messages • {new Date(conv.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <button
                          onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id) }}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-500/20 rounded transition-all"
                        >
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Models Tab with OpenClaw Rarity */}
            <TabsContent value="models" className="flex-1 flex flex-col m-0 mt-4">
              <div className="px-4 mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <Input
                    placeholder="Search models..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-white/5 border-white/10"
                  />
                </div>
              </div>
              <ScrollArea className="flex-1 px-4">
                <div className="space-y-3">
                  {/* Local Models */}
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Downloaded</div>
                  {filteredModels.filter(m => m.downloaded).map(model => (
                    <div
                      key={model.id}
                      onClick={() => setSelectedModel(model)}
                      className={`p-3 rounded-lg cursor-pointer border transition-all ${
                        selectedModel.id === model.id 
                          ? 'bg-indigo-500/10 border-indigo-500/30' 
                          : 'bg-white/5 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium">{model.name}</p>
                            {model.rarity && (
                              <span className={`text-[10px] px-1.5 py-0.5 rounded bg-gradient-to-r ${getRarityColor(model.rarity)} text-white font-bold uppercase`}>
                                {model.rarity}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{model.size}</p>
                          {model.power && (
                            <div className="flex items-center gap-2 mt-2">
                              <Zap className="w-3 h-3 text-yellow-400" />
                              <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full bg-gradient-to-r ${getRarityColor(model.rarity)}`}
                                  style={{ width: `${model.power}%` }}
                                />
                              </div>
                              <span className="text-[10px] text-yellow-400">{model.power}</span>
                            </div>
                          )}
                          <div className="flex gap-1 mt-2">
                            {model.tags.map(tag => (
                              <Badge key={tag} variant="secondary" className="text-[10px] bg-white/10">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                          <span className="text-[10px] text-green-400">Ready</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Available Models */}
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-6">Available</div>
                  {filteredModels.filter(m => !m.downloaded).map(model => (
                    <div
                      key={model.id}
                      className={`p-3 rounded-lg bg-white/5 border border-white/10 ${model.rarity === 'legendary' ? 'shadow-lg ' + getRarityGlow(model.rarity) : ''}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium">{model.name}</p>
                            {model.rarity && (
                              <span className={`text-[10px] px-1.5 py-0.5 rounded bg-gradient-to-r ${getRarityColor(model.rarity)} text-white font-bold uppercase`}>
                                {model.rarity}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{model.description}</p>
                          <p className="text-xs text-gray-500">{model.size}</p>
                          {model.power && (
                            <div className="flex items-center gap-2 mt-2">
                              <Zap className="w-3 h-3 text-yellow-400" />
                              <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full bg-gradient-to-r ${getRarityColor(model.rarity)}`}
                                  style={{ width: `${model.power}%` }}
                                />
                              </div>
                              <span className="text-[10px] text-yellow-400">{model.power}</span>
                            </div>
                          )}
                          <div className="flex gap-1 mt-2">
                            {model.tags.map(tag => (
                              <Badge key={tag} variant="secondary" className="text-[10px] bg-white/10">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      {downloadProgress[model.id] !== undefined && downloadProgress[model.id] < 100 ? (
                        <div className="mt-3">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-400">Downloading...</span>
                            <span className="text-indigo-400">{Math.round(downloadProgress[model.id])}%</span>
                          </div>
                          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <div 
                              className={`h-full bg-gradient-to-r ${getRarityColor(model.rarity)} transition-all`}
                              style={{ width: `${downloadProgress[model.id]}%` }}
                            />
                          </div>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => downloadModel(model.id)}
                          className="w-full mt-3 border-white/20 hover:bg-white/10"
                        >
                          <Download className="w-3 h-3 mr-2" />
                          {model.rarity === 'legendary' ? 'Claim Legendary' : 'Download'}
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Tests Tab */}
            <TabsContent value="tests" className="flex-1 flex flex-col m-0 mt-4">
              <ScrollArea className="flex-1 px-4">
                <div className="space-y-2">
                  <div 
                    onClick={() => setShowTestPanel(true)}
                    className="p-3 rounded-lg bg-gradient-to-r from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 cursor-pointer hover:from-indigo-500/30 hover:to-purple-500/30 transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <Play className="w-4 h-4 text-indigo-400" />
                      <span className="text-sm font-medium">Open Test Arena</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Complete tests to earn XP!</p>
                  </div>
                  
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mt-4">Categories</div>
                  {categories.slice(1).map(cat => (
                    <div
                      key={cat.id}
                      onClick={() => { setSelectedTestCategory(cat.id); setShowTestPanel(true) }}
                      className="p-3 rounded-lg bg-white/5 border border-white/10 cursor-pointer hover:border-white/20 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        <cat.icon className="w-4 h-4 text-gray-400" />
                        <span className="text-sm">{cat.name}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements" className="flex-1 flex flex-col m-0 mt-4">
              <ScrollArea className="flex-1 px-4">
                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-gradient-to-r from-yellow-500/20 via-orange-500/20 to-red-500/20 border border-yellow-500/30">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Achievements</span>
                      <span className="text-xs text-yellow-400">
                        {achievements.filter(a => a.unlocked).length}/{achievements.length}
                      </span>
                    </div>
                  </div>
                  
                  {achievements.map(achievement => (
                    <div
                      key={achievement.id}
                      className={`p-3 rounded-lg border transition-all ${
                        achievement.unlocked
                          ? 'bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/30'
                          : 'bg-white/5 border-white/10 opacity-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          achievement.unlocked
                            ? 'bg-gradient-to-br from-yellow-400 to-orange-500'
                            : 'bg-gray-700'
                        }`}>
                          <achievement.icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className={`text-sm font-medium ${achievement.unlocked ? 'text-white' : 'text-gray-500'}`}>
                              {achievement.name}
                            </p>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-bold ${
                              achievement.rarity === 'platinum' ? 'bg-purple-500/30 text-purple-400' :
                              achievement.rarity === 'gold' ? 'bg-yellow-500/30 text-yellow-400' :
                              achievement.rarity === 'silver' ? 'bg-gray-400/30 text-gray-400' :
                              'bg-orange-600/30 text-orange-400'
                            }`}>
                              {achievement.rarity}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500">{achievement.description}</p>
                          {achievement.unlocked && (
                            <p className="text-xs text-yellow-400 mt-1">+{achievement.xp} XP earned!</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-white/10">
            <div className="flex items-center gap-3 p-2 rounded-lg bg-white/5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Cpu className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{selectedModel.name}</p>
                <p className="text-xs text-green-400">Active</p>
              </div>
              <Settings className="w-4 h-4 text-gray-400 cursor-pointer hover:text-white" />
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <div className="h-14 border-b border-white/10 flex items-center justify-between px-4 glass-strong">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
              {currentConversation && (
                <div>
                  <h2 className="font-medium">{currentConversation.title}</h2>
                  <p className="text-xs text-gray-400">{selectedModel.name}</p>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {/* Game Mode Toggle */}
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowGameMode(!showGameMode)}
                    className={`hover:bg-white/10 ${showGameMode ? 'text-yellow-400' : ''}`}
                  >
                    <Gamepad2 className="w-4 h-4 mr-2" />
                    {showGameMode ? 'ON' : 'OFF'}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Game Mode</TooltipContent>
              </Tooltip>

              {/* Install Button */}
              {!isInstalled && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={installApp}
                      className="hover:bg-white/10 text-indigo-400"
                    >
                      <ArrowDownToLine className="w-4 h-4 mr-2" />
                      Install
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Add to Home Screen</TooltipContent>
                </Tooltip>
              )}
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setShowTestPanel(true)}
                    className="hover:bg-white/10"
                  >
                    <Sparkles className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Test Arena</TooltipContent>
              </Tooltip>
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setShowAchievements(true)}
                    className="hover:bg-white/10"
                  >
                    <Trophy className="w-4 h-4 text-yellow-400" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Achievements</TooltipContent>
              </Tooltip>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="hover:bg-white/10">
                    <Settings className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-[#1a1a1a] border-white/10 text-white max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Settings</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6 py-4">
                    <div>
                      <h3 className="text-sm font-medium mb-3">Model Configuration</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">Temperature</span>
                          <Input type="number" defaultValue={0.7} className="w-24 bg-white/5 border-white/10" />
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">Max Tokens</span>
                          <Input type="number" defaultValue={2048} className="w-24 bg-white/5 border-white/10" />
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">Context Length</span>
                          <Input type="number" defaultValue={4096} className="w-24 bg-white/5 border-white/10" />
                        </div>
                      </div>
                    </div>
                    <Separator className="bg-white/10" />
                    <div>
                      <h3 className="text-sm font-medium mb-3">System Prompt</h3>
                      <textarea 
                        className="w-full h-24 bg-white/5 border border-white/10 rounded-lg p-3 text-sm resize-none"
                        placeholder="Enter system prompt..."
                        defaultValue="You are a helpful AI assistant."
                      />
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col min-h-0">
            {messages.length === 0 ? (
              // Empty State with OpenClaw Theme
              <div className="flex-1 flex flex-col items-center justify-center p-8">
                <div className="relative">
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center animate-float shadow-lg shadow-purple-500/30">
                    <Gamepad2 className="w-12 h-12 text-white" />
                  </div>
                  {showGameMode && (
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center animate-bounce">
                      <Zap className="w-4 h-4 text-black" />
                    </div>
                  )}
                </div>
                <h2 className="text-2xl font-bold mb-2 mt-6">Welcome to the Arena</h2>
                <p className="text-gray-400 text-center max-w-md mb-4">
                  Battle test {selectedModel.name} and earn XP! Complete achievements to level up.
                </p>
                
                {/* Stats Display */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-yellow-500/20 rounded-full border border-yellow-500/30">
                    <Trophy className="w-4 h-4 text-yellow-400" />
                    <span className="text-sm">Level {playerLevel}</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 rounded-full border border-purple-500/30">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span className="text-sm">{playerXP} XP</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-500/20 rounded-full border border-orange-500/30">
                    <Flame className="w-4 h-4 text-orange-400" />
                    <span className="text-sm">{streak} Streak</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 max-w-lg w-full">
                  {[
                    'Explain quantum computing',
                    'Write a Python function',
                    'Help me debug this code',
                    'Summarize this article'
                  ].map((suggestion, i) => (
                    <button
                      key={i}
                      onClick={() => { setInputMessage(suggestion); inputRef.current?.focus() }}
                      className="p-3 text-left text-sm bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 hover:border-white/20 transition-all"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              // Messages
              <ScrollArea className="flex-1 px-4 py-6">
                <div className="max-w-3xl mx-auto space-y-6">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.role === 'user' 
                          ? 'bg-indigo-500' 
                          : 'bg-gradient-to-br from-indigo-500 to-purple-600'
                      }`}>
                        {message.role === 'user' ? (
                          <span className="text-sm font-medium">U</span>
                        ) : (
                          <Cpu className="w-4 h-4" />
                        )}
                      </div>
                      <div className={`flex-1 max-w-[85%] ${
                        message.role === 'user' ? 'message-user' : 'message-assistant'
                      } rounded-2xl p-4`}>
                        {/* Attachments */}
                        {message.attachments && message.attachments.length > 0 && (
                          <div className="flex flex-wrap gap-2 mb-3">
                            {message.attachments.map(att => {
                              const FileIcon = getFileIcon(att.type)
                              return (
                                <div key={att.id} className="flex items-center gap-2 p-2 bg-black/30 rounded-lg">
                                  <FileIcon className="w-4 h-4 text-indigo-400" />
                                  <span className="text-xs">{att.name}</span>
                                  <span className="text-[10px] text-gray-500">{att.size}</span>
                                  {att.type === 'image' && (
                                    <img src={att.url} alt={att.name} className="w-16 h-16 object-cover rounded mt-2" />
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        )}
                        <div className="text-sm leading-relaxed whitespace-pre-wrap">
                          {message.content}
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-[10px] text-gray-500">
                            {message.timestamp.toLocaleTimeString()}
                          </span>
                          {message.model && (
                            <span className="text-[10px] text-indigo-400">{message.model}</span>
                          )}
                          {activeAgent && message.role === 'assistant' && (
                            <span className="text-[10px] text-purple-400 flex items-center gap-1">
                              <Bot className="w-3 h-3" />
                              {activeAgent.name}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {isGenerating && (
                    <div className="flex gap-4">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                        <Cpu className="w-4 h-4" />
                      </div>
                      <div className="message-assistant rounded-2xl p-4 flex items-center gap-2">
                        <div className="flex gap-1">
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                        <span className="text-sm text-gray-400">Thinking...</span>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
            )}

            {/* Input Area */}
            <div className="p-4 border-t border-white/10">
              <div className="max-w-3xl mx-auto">
                {/* Attachment Preview */}
                {attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-3">
                    {attachments.map(att => {
                      const FileIcon = getFileIcon(att.type)
                      return (
                        <div key={att.id} className="flex items-center gap-2 p-2 bg-white/10 rounded-lg border border-white/10">
                          <FileIcon className="w-4 h-4 text-indigo-400" />
                          <span className="text-xs">{att.name}</span>
                          <span className="text-[10px] text-gray-500">{att.size}</span>
                          <button 
                            onClick={() => removeAttachment(att.id)}
                            className="p-1 hover:bg-red-500/20 rounded"
                          >
                            <X className="w-3 h-3 text-red-400" />
                          </button>
                        </div>
                      )
                    })}
                  </div>
                )}

                {/* Chat Bar */}
                <div className="relative">
                  <textarea
                    ref={inputRef}
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        sendMessage()
                      }
                    }}
                    placeholder={activeAgent ? `Using ${activeAgent.name}...` : "Message..."}
                    rows={1}
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-4 pr-36 py-4 text-sm resize-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500/50 transition-all"
                    style={{ minHeight: '56px', maxHeight: '200px' }}
                  />
                  
                  {/* Chat Bar Buttons */}
                  <div className="absolute right-2 bottom-2 flex items-center gap-1">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => fileInputRef.current?.click()}
                          className="h-8 w-8 hover:bg-white/10"
                        >
                          <Paperclip className="w-4 h-4 text-gray-400" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Attach File</TooltipContent>
                    </Tooltip>
                    <input ref={fileInputRef} type="file" multiple onChange={handleFileUpload} className="hidden" />

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setShowConnectors(true)}
                          className={`h-8 w-8 hover:bg-white/10 ${connectors.some(c => c.connected) ? 'text-green-400' : ''}`}
                        >
                          <Plug className="w-4 h-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Connectors</TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setShowAgents(true)}
                          className={`h-8 w-8 hover:bg-white/10 ${activeAgent ? 'text-purple-400' : ''}`}
                        >
                          <Bot className="w-4 h-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>AI Agents</TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openMediaGallery('video')}
                          className="h-8 w-8 hover:bg-white/10"
                        >
                          <Film className="w-4 h-4 text-gray-400" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Add Video</TooltipContent>
                    </Tooltip>

                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openMediaGallery('image')}
                          className="h-8 w-8 hover:bg-white/10"
                        >
                          <Camera className="w-4 h-4 text-gray-400" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Add Image</TooltipContent>
                    </Tooltip>

                    <Button
                      onClick={sendMessage}
                      disabled={(!inputMessage.trim() && attachments.length === 0) || isGenerating}
                      className="btn-primary text-white p-2 h-8 w-8"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-gray-500 text-center mt-2">
                  Press Enter to send, Shift+Enter for new line
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Test Panel - OpenClaw Arena Style */}
        {showTestPanel && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="w-full max-w-5xl h-[80vh] bg-gradient-to-b from-[#1a1a2e] to-[#0d0d0d] border border-purple-500/30 rounded-2xl flex flex-col shadow-2xl shadow-purple-500/20">
              {/* Test Panel Header */}
              <div className="flex items-center justify-between p-6 border-b border-purple-500/30 bg-gradient-to-r from-purple-900/30 to-indigo-900/30">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 flex items-center justify-center shadow-lg">
                    <Sword className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">Test Arena</h2>
                    <p className="text-sm text-gray-400">Battle test {selectedModel.name} • Earn XP</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-4 py-2 bg-yellow-500/20 rounded-lg border border-yellow-500/30">
                    <Trophy className="w-5 h-5 text-yellow-400" />
                    <span className="font-bold">{playerXP} XP</span>
                  </div>
                  <Button
                    onClick={() => runAllTests(selectedTestCategory)}
                    className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Battle All
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowTestPanel(false)}
                    className="hover:bg-white/10"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              {/* Test Panel Content */}
              <div className="flex-1 flex overflow-hidden">
                {/* Category Sidebar */}
                <div className="w-48 border-r border-white/10 p-4">
                  <div className="space-y-1">
                    {categories.map(cat => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedTestCategory(cat.id)}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all ${
                          selectedTestCategory === cat.id
                            ? 'bg-gradient-to-r from-indigo-500/30 to-purple-500/30 text-indigo-400 border border-indigo-500/30'
                            : 'hover:bg-white/5 text-gray-400'
                        }`}
                      >
                        <cat.icon className="w-4 h-4" />
                        {cat.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tests List */}
                <ScrollArea className="flex-1 p-6">
                  <div className="space-y-4">
                    {filteredTests.map(test => {
                      const result = testResults[test.id]
                      const isRunning = runningTests.has(test.id)
                      
                      return (
                        <div
                          key={test.id}
                          className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge className={`${getDifficultyColor(test.difficulty)} text-[10px] uppercase font-bold`}>
                                  {test.difficulty}
                                </Badge>
                                <h3 className="font-medium">{test.name}</h3>
                                <span className="text-xs text-yellow-400 flex items-center gap-1">
                                  <Sparkles className="w-3 h-3" />
                                  +{test.xp} XP
                                </span>
                              </div>
                              <p className="text-sm text-gray-400 mb-2">{test.description}</p>
                              <div className="p-3 rounded-lg bg-black/30 text-sm font-mono text-gray-300">
                                {test.prompt}
                              </div>
                              
                              {result && (
                                <div className="mt-4 p-4 rounded-lg bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30">
                                  <div className="flex items-center gap-2 mb-2">
                                    <Check className="w-4 h-4 text-green-400" />
                                    <span className="text-sm text-green-400 font-bold">Victory!</span>
                                    <span className="text-xs text-gray-500">({result.time}ms)</span>
                                    <span className="text-xs text-yellow-400 ml-auto">+{test.xp} XP earned</span>
                                  </div>
                                  <p className="text-sm text-gray-300">{result.response}</p>
                                </div>
                              )}
                            </div>
                            
                            <div className="ml-4">
                              {isRunning ? (
                                <div className="flex items-center gap-2">
                                  <div className="w-4 h-4 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                                  <span className="text-sm text-gray-400">Battling...</span>
                                </div>
                              ) : result ? (
                                <div className="flex items-center gap-1 text-green-400">
                                  <Check className="w-5 h-5" />
                                </div>
                              ) : (
                                <Button
                                  size="sm"
                                  onClick={() => runTest(test)}
                                  className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                                >
                                  <Sword className="w-3 h-3 mr-1" />
                                  Battle
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </ScrollArea>
              </div>
            </div>
          </div>
        )}

        {/* Connectors Panel */}
        {showConnectors && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="w-full max-w-2xl bg-[#1a1a1a] border border-white/10 rounded-2xl flex flex-col max-h-[80vh]">
              <div className="flex items-center justify-between p-6 border-b border-white/10">
                <div>
                  <h2 className="text-xl font-bold">Connectors</h2>
                  <p className="text-sm text-gray-400">Connect external services and data sources</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setShowConnectors(false)} className="hover:bg-white/10">
                  <X className="w-5 h-5" />
                </Button>
              </div>
              
              <ScrollArea className="flex-1 p-6">
                <div className="grid grid-cols-2 gap-4">
                  {connectors.map(connector => (
                    <div
                      key={connector.id}
                      className={`p-4 rounded-xl border transition-all ${
                        connector.connected
                          ? 'bg-green-500/10 border-green-500/30'
                          : 'bg-white/5 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: connector.color + '30' }}>
                            <connector.icon className="w-5 h-5" style={{ color: connector.color }} />
                          </div>
                          <div>
                            <h3 className="font-medium">{connector.name}</h3>
                            <p className="text-xs text-gray-400">{connector.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {connector.connected ? (
                            <div className="flex items-center gap-1 text-green-400">
                              <CheckCircle2 className="w-4 h-4" />
                              <span className="text-xs">Connected</span>
                            </div>
                          ) : (
                            <span className="text-xs text-gray-500">Not connected</span>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => toggleConnector(connector.id)}
                        className={`w-full mt-4 ${
                          connector.connected
                            ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                            : 'btn-primary text-white'
                        }`}
                      >
                        {connector.connected ? 'Disconnect' : 'Connect'}
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        )}

        {/* Agents Panel */}
        {showAgents && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="w-full max-w-2xl bg-[#1a1a1a] border border-white/10 rounded-2xl flex flex-col max-h-[80vh]">
              <div className="flex items-center justify-between p-6 border-b border-white/10">
                <div>
                  <h2 className="text-xl font-bold">AI Agents</h2>
                  <p className="text-sm text-gray-400">Specialized agents for different tasks</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setShowAgents(false)} className="hover:bg-white/10">
                  <X className="w-5 h-5" />
                </Button>
              </div>
              
              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  {agents.map(agent => (
                    <div
                      key={agent.id}
                      onClick={() => toggleAgent(agent)}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        activeAgent?.id === agent.id
                          ? 'bg-purple-500/10 border-purple-500/30'
                          : 'bg-white/5 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                            <agent.icon className="w-5 h-5 text-purple-400" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium">{agent.name}</h3>
                              <span className="text-[10px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-400 rounded">Lv.{agent.level}</span>
                            </div>
                            <p className="text-xs text-gray-400">{agent.description}</p>
                            <div className="flex flex-wrap gap-1 mt-2">
                              {agent.capabilities.map(cap => (
                                <Badge key={cap} variant="secondary" className="text-[10px] bg-white/10">
                                  {cap}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {activeAgent?.id === agent.id ? (
                            <div className="flex items-center gap-1 text-purple-400">
                              <CheckCircle2 className="w-4 h-4" />
                              <span className="text-xs">Active</span>
                            </div>
                          ) : (
                            <ChevronRight className="w-5 h-5 text-gray-500" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        )}

        {/* Media Gallery */}
        {showMediaGallery && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="w-full max-w-4xl bg-[#1a1a1a] border border-white/10 rounded-2xl flex flex-col max-h-[80vh]">
              <div className="flex items-center justify-between p-6 border-b border-white/10">
                <div>
                  <h2 className="text-xl font-bold">Select {mediaType === 'image' ? 'Image' : 'Video'}</h2>
                  <p className="text-sm text-gray-400">Choose from your library or upload new</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className="border-white/20">
                    <Plus className="w-4 h-4 mr-2" />
                    Upload {mediaType === 'image' ? 'Image' : 'Video'}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => setShowMediaGallery(false)} className="hover:bg-white/10">
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </div>
              
              <ScrollArea className="flex-1 p-6">
                <div className="grid grid-cols-3 gap-4">
                  {sampleMedia.map(media => (
                    <div
                      key={media.id}
                      onClick={() => selectMedia(media)}
                      className="relative group cursor-pointer rounded-xl overflow-hidden border border-white/10 hover:border-indigo-500/50 transition-all"
                    >
                      <img src={media.url} alt={media.name} className="w-full h-40 object-cover group-hover:scale-105 transition-transform" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Plus className="w-8 h-8 text-white" />
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                        <p className="text-sm font-medium">{media.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        )}

        {/* Achievements Modal */}
        {showAchievements && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="w-full max-w-2xl bg-gradient-to-b from-[#1a1a2e] to-[#0d0d0d] border border-yellow-500/30 rounded-2xl flex flex-col max-h-[80vh] shadow-2xl shadow-yellow-500/10">
              <div className="flex items-center justify-between p-6 border-b border-yellow-500/30 bg-gradient-to-r from-yellow-900/30 to-orange-900/30">
                <div className="flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-yellow-400" />
                  <div>
                    <h2 className="text-xl font-bold">Achievements</h2>
                    <p className="text-sm text-gray-400">Complete challenges to earn rewards</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setShowAchievements(false)} className="hover:bg-white/10">
                  <X className="w-5 h-5" />
                </Button>
              </div>
              
              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  {achievements.map(achievement => (
                    <div
                      key={achievement.id}
                      className={`p-4 rounded-xl border transition-all ${
                        achievement.unlocked
                          ? 'bg-gradient-to-r from-yellow-500/10 via-orange-500/10 to-red-500/10 border-yellow-500/30'
                          : 'bg-white/5 border-white/10 opacity-50'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                          achievement.unlocked
                            ? 'bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 shadow-lg shadow-orange-500/30'
                            : 'bg-gray-700'
                        }`}>
                          <achievement.icon className="w-7 h-7 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className={`text-lg font-bold ${achievement.unlocked ? 'text-white' : 'text-gray-500'}`}>
                              {achievement.name}
                            </p>
                            <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-bold ${
                              achievement.rarity === 'platinum' ? 'bg-purple-500/30 text-purple-400' :
                              achievement.rarity === 'gold' ? 'bg-yellow-500/30 text-yellow-400' :
                              achievement.rarity === 'silver' ? 'bg-gray-400/30 text-gray-400' :
                              'bg-orange-600/30 text-orange-400'
                            }`}>
                              {achievement.rarity}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">{achievement.description}</p>
                          {achievement.unlocked && (
                            <p className="text-sm text-yellow-400 mt-1 font-medium">+{achievement.xp} XP earned!</p>
                          )}
                        </div>
                        {achievement.unlocked && (
                          <CheckCircle2 className="w-6 h-6 text-green-400" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        )}
      </div>
    </TooltipProvider>
  )
}

export default App
