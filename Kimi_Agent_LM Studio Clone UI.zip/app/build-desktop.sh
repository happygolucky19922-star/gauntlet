#!/bin/bash

# LM Studio Clone Desktop Build Script
# This script builds the desktop application using Tauri

set -e

echo "=========================================="
echo "LM Studio Clone - Desktop Build Script"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Node.js is installed
check_node() {
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_status "Node.js found: $NODE_VERSION"
        return 0
    else
        print_error "Node.js is not installed!"
        echo "Please install Node.js from: https://nodejs.org/"
        return 1
    fi
}

# Check if Rust is installed
check_rust() {
    if command -v rustc &> /dev/null; then
        RUST_VERSION=$(rustc --version)
        print_status "Rust found: $RUST_VERSION"
        return 0
    else
        print_warning "Rust is not installed!"
        echo "Installing Rust..."
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        source $HOME/.cargo/env
        print_status "Rust installed successfully!"
        return 0
    fi
}

# Check platform-specific dependencies
check_platform_deps() {
    OS="$(uname -s)"
    case "$OS" in
        Linux*)
            print_status "Detected Linux"
            if command -v apt-get &> /dev/null; then
                print_status "Installing dependencies for Debian/Ubuntu..."
                sudo apt-get update
                sudo apt-get install -y libwebkit2gtk-4.0-dev build-essential curl wget file libssl-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev
            elif command -v dnf &> /dev/null; then
                print_status "Installing dependencies for Fedora..."
                sudo dnf install -y webkit2gtk3-devel openssl-devel curl wget file libappindicator-gtk3-devel librsvg2-devel
            elif command -v pacman &> /dev/null; then
                print_status "Installing dependencies for Arch..."
                sudo pacman -S --needed webkit2gtk base-devel curl wget file openssl appindicator-gtk librsvg
            else
                print_warning "Unknown package manager. Please install dependencies manually."
            fi
            ;;
        Darwin*)
            print_status "Detected macOS"
            if ! command -v xcode-select &> /dev/null; then
                print_status "Installing Xcode Command Line Tools..."
                xcode-select --install
            fi
            ;;
        CYGWIN*|MINGW*|MSYS*)
            print_status "Detected Windows"
            print_warning "Please ensure Microsoft Visual Studio C++ Build Tools are installed"
            print_warning "Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/"
            ;;
        *)
            print_warning "Unknown OS: $OS"
            ;;
    esac
}

# Install Node.js dependencies
install_deps() {
    print_status "Installing Node.js dependencies..."
    npm install
    print_status "Dependencies installed!"
}

# Build the desktop app
build_app() {
    print_status "Building desktop application..."
    print_status "This may take a few minutes..."
    echo ""
    
    npm run tauri-build
    
    echo ""
    print_status "Build completed successfully!"
}

# Show build output location
show_output() {
    OS="$(uname -s)"
    echo ""
    echo "=========================================="
    print_status "Build complete! Find your installer at:"
    echo "=========================================="
    
    case "$OS" in
        Linux*)
            echo ""
            echo "DEB Package:"
            find src-tauri/target/release/bundle/deb -name "*.deb" 2>/dev/null | head -1
            echo ""
            echo "RPM Package:"
            find src-tauri/target/release/bundle/rpm -name "*.rpm" 2>/dev/null | head -1
            echo ""
            echo "AppImage:"
            find src-tauri/target/release/bundle/appimage -name "*.AppImage" 2>/dev/null | head -1
            ;;
        Darwin*)
            echo ""
            echo "DMG Image:"
            find src-tauri/target/release/bundle/dmg -name "*.dmg" 2>/dev/null | head -1
            echo ""
            echo "APP Bundle:"
            find src-tauri/target/release/bundle/macos -name "*.app" 2>/dev/null | head -1
            ;;
        CYGWIN*|MINGW*|MSYS*)
            echo ""
            echo "MSI Installer:"
            find src-tauri/target/release/bundle/msi -name "*.msi" 2>/dev/null | head -1
            echo ""
            echo "EXE Installer:"
            find src-tauri/target/release/bundle/nsis -name "*.exe" 2>/dev/null | head -1
            ;;
    esac
    
    echo ""
    echo "=========================================="
}

# Main function
main() {
    echo ""
    print_status "Starting build process..."
    echo ""
    
    # Check prerequisites
    check_node || exit 1
    check_rust
    check_platform_deps
    
    echo ""
    
    # Install dependencies
    install_deps
    
    echo ""
    
    # Build the app
    build_app
    
    # Show output
    show_output
    
    print_status "Installation complete! Enjoy using LM Studio Clone!"
}

# Run main function
main
